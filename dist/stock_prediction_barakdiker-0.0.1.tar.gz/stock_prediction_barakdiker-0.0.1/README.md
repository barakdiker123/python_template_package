



# Yeshurun Second Degree final project 
This project will create backtest for comparing 2 investing strategies 
the first is 'Buy N Hold '
the second is prediction via regression 

## This project is an extension of cash_analysis 

here is the link for the parent project 
[CashAnalysis](https://barakdiker123.github.io/CashAnalysis/)


## Credits 

* Barak Nadav Diker 
* Yeshurun 
